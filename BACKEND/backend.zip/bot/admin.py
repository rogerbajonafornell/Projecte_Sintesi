from django.contrib import admin
from .models import Usuari, Comanda

# Register your models here.
admin.site.register(Usuari)
admin.site.register(Comanda)